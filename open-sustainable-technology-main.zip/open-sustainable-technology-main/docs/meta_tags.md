---
description: Open technology projects sustaining stable climate, energy supply and vital natural resources
image: earth,gif
---

